/*
 * This program is free software; you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License, version 2.1 as published by the Free Software
 * Foundation.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * program; if not, you can obtain a copy at http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html
 * or from the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * Copyright (c) 2007 - 2009 Pentaho Corporation and Contributors.  All rights reserved.
 */

package org.pentaho.reporting.libraries.css.keys.box;

import org.pentaho.reporting.libraries.css.values.CSSConstant;

/**
 * Describes how replaced content should be scaled if neither the width or
 * height of an element is set to 'auto'.
 *
 * @author Thomas Morgner
 */
public class Fit
{
  public static final CSSConstant FILL = new CSSConstant("fill");
  public static final CSSConstant NONE = new CSSConstant("none");
  public static final CSSConstant MEET = new CSSConstant("meet");
  public static final CSSConstant SLICE = new CSSConstant("slice");

  private Fit()
  {
  }
}
